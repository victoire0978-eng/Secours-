---
name: NLSbox routing
description: Deployment routing constraint for the NLSbox app and the shared API scaffold.
---

NLSbox must own the root path and its `/api/*` proxy routes. The generic API artifact must not claim the broad `/api` prefix, or preview and published API calls are routed away from NLSbox.

**Why:** The workspace proxy chooses the most specific registered path before the NLSbox root service, so an idle generic `/api` service causes blank or 502 API responses even while NLSbox itself is healthy.

**How to apply:** Keep the generic API artifact limited to a non-conflicting health path, or move NLSbox API routes into the service that owns `/api`; never restore a broad `/api` claim without updating NLSbox routing.