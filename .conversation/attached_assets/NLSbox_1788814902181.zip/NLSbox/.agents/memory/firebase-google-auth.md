---
name: Firebase Google authentication
description: Operational requirement for Google sign-in after moving the Firebase app to a Replit-hosted domain.
---

Keep the imported Firebase client configuration unchanged. Google OAuth also requires the current Replit preview hostname and the eventual published hostname to be listed in Firebase Authentication's Authorized domains, with Google enabled as a sign-in provider.

**Why:** Firebase validates the hosting origin server-side; changing client config or popup code cannot authorize a new Replit domain.

**How to apply:** Preserve `firebase-applet-config.json` and `firebase.ts`. Use popup sign-in with redirect fallback, and when `auth/unauthorized-domain` appears, add the exact hostname in Firebase Console before retrying.